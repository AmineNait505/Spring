package org.example;

import entites.livre;

import entites.user;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repositories.LivreRepository;
import repositories.UserRepository;


@EnableJpaRepositories(basePackages = "repositories")
@EntityScan(basePackages = "entites")
@SpringBootApplication
public class ExRouaAppliation {
    public static void main(String[] args) {
        SpringApplication.run(ExRouaAppliation.class, args);
    }

    @Bean
    public CommandLineRunner start(LivreRepository livreRepository , UserRepository userrepository) {
        return args -> {
            livre p1 = new livre(null,"l1", "ilmkjghbnilj","muiojfio");
            livre p2 = new livre(null, "l2", "iuigb","lkhjfgbiuj");
            livre p3 = new livre(null, "l3", "kjnbuifq","oiuuyi");
            livre p4 = new livre(null, "l4","iuuingnio","ôipqio");
            livreRepository.save(p1);
            livreRepository.save(p2);
            livreRepository.save(p3);
            livreRepository.save(p4);
            System.out.println("Livres ajoutés avec succès!");
            livreRepository.findAll().forEach(livre -> System.out.println(livre.getId() + " name: " + livre.getName() + " descr: " + livre.getDescr()));
            user u1 = new user(5L,"ahmed","muiojfio");
            user u2 = new user( 10L,"amine","kuoydbf");
            user u3 = new user( 12L,"jerbi","oiuyfebui");
            userrepository.save(u1);
            userrepository.save(u2);
            userrepository.save(u3);
            //for testing if the data base has been updated
            System.out.println("Users ajoutés avec succès!");
            userrepository.findAll().forEach(user -> System.out.println(user.getId() + " name: " + user.getName() + "password" + user.getPswd()));

        };
    }
}
