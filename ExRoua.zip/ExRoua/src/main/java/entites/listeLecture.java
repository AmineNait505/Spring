package entites;

public class listeLecture {
}
