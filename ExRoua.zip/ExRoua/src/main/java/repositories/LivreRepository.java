package repositories;

import entites.livre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivreRepository  extends JpaRepository<livre,Long> {
}
