package web;

import entites.livre;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import repositories.LivreRepository;

import java.util.List;


@Component
@Path("/livre")
public class LivreJAXRSAPI {
    @Autowired
    private LivreRepository livreRepository;
    @Path("/livres")
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Transactional
    public List<livre> livreList(){
        return livreRepository.findAll();
    }
    @Path("/livres/{id}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public livre getone(@PathParam(value="id")Long id){
        return livreRepository.findById(id).get();
    }
    @Path("/livre")
    @POST
    @Produces({MediaType.APPLICATION_JSON})
    public livre save(livre livre){
        return livreRepository.save(livre);
    }
    @Path("/livres/{id}")
    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    public livre update(livre produit ,@PathParam("id")Long id){
        produit.setId(id);
        return livreRepository.save(produit);
    }
    @Path("/livres/{id}")
    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    public void delete (@PathParam("id")Long id){
        livreRepository.deleteById(id);
    }




}