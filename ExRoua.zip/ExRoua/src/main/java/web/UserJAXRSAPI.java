package web;

import entites.livre;
import entites.user;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import repositories.LivreRepository;
import repositories.UserRepository;

import java.util.List;


@Component
@Path("/user")
public class UserJAXRSAPI {
    @Autowired
    private UserRepository livreRepository;
    @Path("/users")
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Transactional
    public List<user> livreList(){
        return livreRepository.findAll();
    }
    @Path("/users/{id}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public user getone(@PathParam(value="id")Long id){
        return livreRepository.findById(id).get();
    }
    @Path("/user")
    @POST
    @Produces({MediaType.APPLICATION_JSON})
    public user save(user livre){
        return livreRepository.save(livre);
    }
    @Path("/users/{id}")
    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    public user update(user produit ,@PathParam("id")Long id){
        produit.setId(id);
        return livreRepository.save(produit);
    }
    @Path("/users/{id}")
    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    public void delete (@PathParam("id")Long id){
        livreRepository.deleteById(id);
    }




}